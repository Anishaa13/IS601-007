flask-principal jsons

403, 404 pages roles blueprint updated formshelpers added dropdown nav fixed closing table in list_sample added updated version of db.py renamed var in init_Db.py (not a functional change) added roles, userroles tables and insert of admin role updated flask_login user lookup to use sessions instead of a db call per request